#include <stdio.h>
#include <MKL25Z4.h>
#include <stdint.h>
#include "core_cm0plus.h"
#include "leds.h"
#include "systick.h"

typedef uint32_t ticktime_t;

ticktime_t count = 0;
ticktime_t temp = 0;

//Systick timer initialization
void SysTick_Initialization()
{
	SysTick->LOAD = 30000;				//for 10ms res
	NVIC_SetPriority (SysTick_IRQn, 3);
	SysTick->VAL = 0;					//Initial value of counter
	SysTick->CTRL &= ~(SysTick_CTRL_CLKSOURCE_Msk); 		//frequency = 3Mhz (ext clock)
	SysTick->CTRL = SysTick_CTRL_TICKINT_Msk | SysTick_CTRL_ENABLE_Msk; //enable interrupt
}

//interrupt handler
void SysTick_Handler()
{
	count += 10;
}

//returns current time since startup
ticktime_t time_now()
{
	return count;
}

//resets the timer
void reset_timer()
{
	temp = count ;
}

//returns time
ticktime_t get_timer()
{
	return (count - temp);
}
