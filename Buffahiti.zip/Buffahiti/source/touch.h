/*
 * touch.h
 *
 */
#ifndef TOUCH_H_
#define TOUCH_H_
#include "stdio.h"
#include "MKL25Z4.h"

/***********Defining macros****************/


#define TOUCH_COUNT ((TSI0->DATA)& 0XFFFF)

/***********Declaring the functions****************/

void Touch_Initialization();
int Touch_Scan(void);
void delay(int iterations);

#endif /* TOUCH_H_ */
