
/***********Defining macros****************/
#define RED_LED_PIN 18
#define GREEN_LED_PIN 19
#define BLUE_LED_PIN 1

#define MASK(x) (1UL << (x))

/***********Declaring the functions****************/
void portInitialize(void);
void pinInitialize(void);
void muxIntialize(void);
void led_on(int rgb);
void led_off();
