/*
 * states.h
 *
 *  Created on: 09-Oct-2022
 *      Author: itssh
 */

#ifndef STATE_MACHINE_H_
#define STATE_MACHINE_H_
#define CROSSWALK_TIME 10000
#define TRANSITION_TIME 1000

#ifdef DEBUG

#define STOP_TIME 5000
#define GO_TIME 5000
#define WARN_TIME 3000

#else

#define STOP_TIME 20000
#define GO_TIME 20000
#define WARN_TIME 5000

#endif


#include "leds.h"


void MainLoop();
#endif /* STATE_MACHINE_H_ */
