#ifndef STATES_H_
#define STATES_H_

/************************Declaring functions***************************/
void MainLoop();

#endif /* STATES_H_ */
