#ifndef SWITCH_H_
#define SWITCH_H_

/***********Declaring the functions****************/
void Switch_Initialization();
void IRQHandler();
int switch_press();

#endif /* SWITCH_H_ */
