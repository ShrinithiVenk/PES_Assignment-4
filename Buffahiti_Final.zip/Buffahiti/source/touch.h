#ifndef TOUCH_H_
#define TOUCH_H_

/***********Declaring the functions****************/

void Touch_Initialization();
int Touch_Scan(void);
void delay(int iterations);

#endif /* TOUCH_H_ */
